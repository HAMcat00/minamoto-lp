## 概要
- 何を・なぜ・どう実装？ スクショ/動画/Lighthouse結果を添付

## チェックリスト
- [ ] Lighthouse (Perf/SEO/A11y/Best) ≧ 90
- [ ] CLS < 0.1, LCP < 2.5s
- [ ] 375px〜崩れなし
- [ ] CTA→LINE 実機(iOS/Android)からOK
- [ ] GA4 DebugViewでイベント（view_section/click_CTA/submit_order）発火確認
