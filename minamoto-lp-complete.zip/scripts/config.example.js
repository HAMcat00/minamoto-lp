// 環境依存の値はここを編集（本番前に config.js にコピー）
window.MINAMOTO_CONFIG = {
  LINE_URL: "https://lin.ee/your-id?utm_source=lp&utm_medium=cta&utm_campaign=order",
  GA_MEASUREMENT_ID: "{{GA_MEASUREMENT_ID}}",
  AB_VARIANTS: ["今すぐ食べる", "LINEで注文"]
};
