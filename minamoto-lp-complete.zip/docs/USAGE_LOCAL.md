# ローカル利用方法
- そのまま `index.html` を開くだけ（静的）
- 設定：`scripts/config.example.js` の `LINE_URL` を本番に合わせて変更
- GA4は本番/Previewで注入（ローカルでは発火テストのみ）
